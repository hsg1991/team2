library(jsonlite)

# json.data <- fromJSON("./tiny_news.json")

# library(jsonlite)
# library(RJSONIO)
# json_data_raw<-fromJSON("tiny_news.json")
# 
# json_file <- lapply(json_data_raw, function(x) {
#   x[sapply(x, is.null)] <- NA
#   unlist(x)
# })
# 
# output <-- do.call("rbind", json_file)
# write.csv(a, file="tiny_news.csv",row.names = FALSE)
# file.show("tiny_news.csv")]


# df <- read.csv("daily.csv", header=TRUE)
