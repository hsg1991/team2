# team2
Bartosz Paszcza, Alan Ponce (SOTON)
Brian Kangwook Lee, Sanggyu Han (KAIST)

Team project description:
